<header>
    <div>
        <img class="logo" src="images/logo.png" alt="logo">
    </div>
    <nav>
        <a href="index.php">home</a>
        <a href="menu.php">menu</a>
        <a href="overons.php">over ons</a>
        <a href="contact.php">contact</a>
    </nav>
    <div class="socials">
        <a href="https://www.instagram.com" target="_blank"><img src="images/instagram.png" alt="instagram"></a>
        <a href="https://www.facebook.com" target="_blank"><img src="images/facebook.png" alt="facebook"></a>
    </div>
</header>